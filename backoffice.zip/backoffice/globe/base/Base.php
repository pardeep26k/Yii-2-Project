<?php

namespace backoffice\globe\base;

class Base extends \common\globe\base\Base
{

}
