<?php

namespace backoffice\globe\carbayin;

use backoffice\globe\base\Base;

class In extends Base
{
	public $languages = [
        'en' => 'English',
        'hi' => 'Hindi'
    ];
    
    public function init()
    {
        parent::init();
    }
}
