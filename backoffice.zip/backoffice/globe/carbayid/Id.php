<?php

namespace backoffice\globe\carbayid;

use backoffice\globe\base\Base;

class Id extends Base
{
	public $languages = [
        'en' => 'English',
        'id' => 'Indonesian'
    ];
    
    public function init()
    {
        parent::init();
    }
    
}